import "./home.scss";

function home() {
  return (
    <div>
      {" "}
      <div>Home</div>
      <div>Home</div>
      <div>Home</div>
      <div>Home</div>
    </div>
  );
}

export default home;
