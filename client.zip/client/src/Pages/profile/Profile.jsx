import "./profile.scss";

function profile() {
  return <div className="profile">Profile</div>;
}

export default profile;
